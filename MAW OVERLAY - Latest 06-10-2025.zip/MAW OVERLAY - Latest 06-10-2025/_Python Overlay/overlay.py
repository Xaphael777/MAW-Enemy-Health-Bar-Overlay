import json
import tkinter as tk
from PIL import Image, ImageTk, ImageFont, ImageDraw
import re
import os
import sys
import time
import math
import traceback # Import traceback for detailed error logging

# --- Configuration ---
SCRIPT_DIR = os.path.dirname(os.path.abspath(sys.argv[0]))
MONSTER_FILE = os.path.join(SCRIPT_DIR, "visible_monsters.json") 
UPDATE_INTERVAL = 10  # milliseconds (how often to refresh the overlay)
SETTINGS_FILE = os.path.join(SCRIPT_DIR, "overlay_settings.json") # Path to the settings file
FONTS_DIR = os.path.join(SCRIPT_DIR, "fonts") # Path to the fonts subdirectory
BOSS_ICONS_DIR = os.path.join(SCRIPT_DIR, "boss icons") # Path to the boss icons subdirectory
ERROR_LOG_FILE = os.path.join(SCRIPT_DIR, "overlay_error.log") # New: Path for error log file

# --- Default Size Configuration (Used if settings file is missing) ---
# FIX REQUIREMENT: These constants are needed for defaults in load_settings
INITIAL_WIDTH = 1920
INITIAL_HEIGHT = 1080

ASSET_DIR = SCRIPT_DIR # Assuming assets are in the same directory as the script
BACKGROUND_PATH = os.path.join(ASSET_DIR, "background.png") # Main bar background
LEFT_CAP_PATH = os.path.join(ASSET_DIR, "left_cap.png")
RIGHT_CAP_PATH = os.path.join(ASSET_DIR, "right_cap.png")
FILL_PATHS = {
    "boss": os.path.join(ASSET_DIR, "fill_boss.png"),
    "crit_monster": os.path.join(ASSET_DIR, "fill_crit.png"), # Added fill for crit monsters
    "normal_monster": os.path.join(ASSET_DIR, "fill_normal.png"),
    "normal_low": os.path.join(ASSET_DIR, "fill_low.png"),
}


class OverlayApp:
    """The main application class for the transparent overlay."""
    def __init__(self, master=None):
        self.root = master if master else tk.Tk()
        self.root.title("Might & Magic Overlay")

        # --- MINIMAL FIX START ---
        # Initialize width and height with default values so load_settings can safely compare them.
        self.width = INITIAL_WIDTH
        self.height = INITIAL_HEIGHT
        # --- MINIMAL FIX END ---
        
        # Initialize other variables needed for state management
        self.error_occurred = False
        self.error_message = ""
        self.current_settings = {}
        self.assets = {}
        self.fonts = {}
        self.boss_icons = {}

        # Load settings immediately to configure initial geometry
        self.load_settings()
        
        # --- Window Configuration ---
        self.root.overrideredirect(True) # Remove window borders and title bar
        self.root.attributes('-alpha', 0.98) # Slight transparency
        self.root.attributes('-topmost', True) # Keep the overlay on top of other windows
        self.root.attributes('-transparentcolor', 'SystemTransparent') # Set the transparent color (system default)

        # Set the initial geometry based on loaded settings
        self.root.geometry(f"{self.width}x{self.height}+0+0")
        
        # Set 'SystemTransparent' as the transparent color
        try:
            # On some systems, this will make the background transparent
            self.root.wm_attributes('-transparentcolor', '#000001')
        except tk.TclError:
            # Fallback for systems where -transparentcolor is not supported
            pass
        
        self.canvas = tk.Canvas(self.root, width=self.width, height=self.height, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)
        
        # Set a black background for the canvas, and use a unique color for transparency key
        # We will use the system transparent color attribute to key out a specific color (like deep purple)
        self.root.config(bg='black') # Use black for the root window
        self.canvas.config(bg='SystemTransparent') # Use the system transparent key color

        self.canvas.create_text(
            self.width / 2, self.height / 2, 
            text="Overlay Initializing...", 
            fill="white", 
            tags="startup_message"
        )
        
        # Load assets and start the update loop
        self.load_assets()
        self.update_loop()

    def log_error(self, message):
        """Logs detailed error message and traceback to a file."""
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        error_details = f"[{timestamp}] {message}\n{traceback.format_exc()}\n---\n"
        try:
            with open(ERROR_LOG_FILE, 'a') as f:
                f.write(error_details)
        except Exception as e:
            print(f"FATAL: Could not write to error log file: {e}")
            print(error_details)
            
    def display_error_on_canvas(self):
        """Displays a critical error message on the overlay."""
        self.canvas.delete("all")
        self.canvas.create_rectangle(0, 0, self.width, self.height, fill="red", stipple="gray50")
        self.canvas.create_text(
            self.width / 2, self.height / 2, 
            text=f"CRITICAL ERROR\n{self.error_message}", 
            fill="white", 
            font=("Arial", 20, "bold"),
            tags="error_message",
            justify=tk.CENTER
        )

    def load_settings(self):
        """Loads and applies settings from the JSON file."""
        try:
            with open(SETTINGS_FILE, 'r') as f:
                settings = json.load(f)
        except FileNotFoundError:
            # If file is not found, use defaults and save the default file
            settings = {
                "width": 1920, # Use hardcoded defaults here too for robustness
                "height": 1080, # Use hardcoded defaults here too for robustness
                "bar_width_scale": 1.0,
                "bar_height_scale": 1.0,
                "text_scale": 1.0,
                "x_offset": 0,
                "y_offset": 0,
                "default_font": "arial.ttf",
                "default_font_size": 18,
                "bar_opacity": 0.8,
                "text_opacity": 1.0
            }
            self.save_settings(settings)
        except json.JSONDecodeError as e:
            self.log_error(f"Settings file corrupted: {e}")
            return # Skip applying corrupted settings

        # Check for window size change and apply
        new_width = settings.get('width', INITIAL_WIDTH)
        new_height = settings.get('height', INITIAL_HEIGHT)

        # Check for resize ONLY if attributes are initialized (which they now are in __init__)
        if new_width != self.width or new_height != self.height:
            self.width = new_width
            self.height = new_height
            self.root.geometry(f"{self.width}x{self.height}+0+0")
            # The canvas needs to be resized too
            self.canvas.config(width=self.width, height=self.height)
            self.canvas.pack(fill="both", expand=True)
            self.load_assets() # Reload assets if the scale changed implicitly
            
        self.current_settings = settings
        self.load_assets() # Reload assets after scale might have been loaded/applied

    def save_settings(self, settings):
        """Saves current settings to the JSON file."""
        try:
            with open(SETTINGS_FILE, 'w') as f:
                json.dump(settings, f, indent=4)
        except Exception as e:
            self.log_error(f"Error saving settings: {e}")
            
    def load_game_data(self):
        """Reads and parses the monster data from the game's file."""
        try:
            with open(MONSTER_FILE, 'r') as f:
                data = json.load(f)
            return data
        except FileNotFoundError:
            # File may not exist yet, return empty list
            return []
        except json.JSONDecodeError as e:
            # Game wrote a malformed file, log and return empty list
            self.log_error(f"Monster data file corrupted: {e}")
            return []
        except Exception as e:
            self.log_error(f"Error reading monster data: {e}")
            return []

    def get_font(self, font_name, size):
        """Loads a font, caching it for reuse."""
        key = (font_name, size)
        if key not in self.fonts:
            try:
                # Prioritize loading from the local fonts directory
                font_path = os.path.join(FONTS_DIR, font_name)
                if not os.path.exists(font_path):
                    # Fallback to system font if local one isn't found
                    font_path = font_name
                    
                self.fonts[key] = ImageFont.truetype(font_path, size)
            except IOError:
                self.log_error(f"Could not load font: {font_name} at size {size}. Falling back to default.")
                self.fonts[key] = ImageFont.load_default()
        return self.fonts[key]

    def load_image(self, path, scale_x=1.0, scale_y=1.0):
        """Loads an image and scales it based on the window and settings scale."""
        try:
            img = Image.open(path).convert("RGBA")
            
            # Apply settings scale
            bar_w_scale = self.current_settings.get('bar_width_scale', 1.0)
            bar_h_scale = self.current_settings.get('bar_height_scale', 1.0)
            
            new_width = int(img.width * scale_x * bar_w_scale)
            new_height = int(img.height * scale_y * bar_h_scale)
            
            # Ensure dimensions are positive
            if new_width <= 0 or new_height <= 0:
                self.log_error(f"Calculated image size is invalid for: {os.path.basename(path)}")
                return None
                
            img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
            return img
        except FileNotFoundError:
            self.log_error(f"Image not found at path: {path}")
            return None
        except Exception as e:
            self.log_error(f"Error loading/resizing image {path}: {e}")
            return None

    def load_assets(self):
        """Loads all required images and fonts."""
        self.assets = {}
        self.fonts = {}
        self.boss_icons = {}
        
        # Load main bar components
        self.assets['background'] = self.load_image(BACKGROUND_PATH)
        self.assets['left_cap'] = self.load_image(LEFT_CAP_PATH)
        self.assets['right_cap'] = self.load_image(RIGHT_CAP_PATH)

        # Load fill components (scaled only by height to allow dynamic width filling)
        self.assets['fill'] = {
            key: self.load_image(path, scale_x=1.0) 
            for key, path in FILL_PATHS.items()
        }

        # Load fonts (initial load for defaults)
        font_size = int(self.current_settings.get('default_font_size', 18) * self.current_settings.get('text_scale', 1.0))
        font_name = self.current_settings.get('default_font', 'arial.ttf')
        self.get_font(font_name, font_size)

    def draw_bar(self, x, y, hp_percent, fill_type, name, is_boss, is_crit, opacity, text_opacity):
        """
        Draws a single health bar onto the main canvas.
        
        Note: Tkinter cannot draw semi-transparent images directly. We use PIL/Pillow to composite
        and apply opacity, then convert the final image to a PhotoImage for Tkinter.
        """
        bar_bg = self.assets.get('background')
        bar_left = self.assets.get('left_cap')
        bar_right = self.assets.get('right_cap')

        # Determine the fill image
        fill_img = self.assets['fill'].get('boss' if is_boss else ('crit_monster' if is_crit else 'normal_monster'))
        if not fill_img:
            self.log_error("Missing required fill image asset.")
            return

        if not bar_bg or not bar_left or not bar_right:
             self.log_error("Missing required bar background assets.")
             return

        # 1. Base Dimensions
        bar_height = bar_bg.height
        bar_width = bar_bg.width
        cap_width = bar_left.width
        
        # 2. Create Base Image (Fully Transparent)
        base_img = Image.new('RGBA', (bar_width, bar_height), (0, 0, 0, 0))
        
        # 3. Apply Opacity to Background Components
        def apply_opacity(img, alpha):
            """Helper to apply alpha to an RGBA image."""
            data = img.getdata()
            new_data = []
            for item in data:
                # item is (R, G, B, A). New alpha is A * alpha
                new_data.append(item[:-1] + (int(item[3] * alpha),))
            img.putdata(new_data)
            return img

        # Apply opacity to all components before compositing
        alpha_factor = max(0.0, min(1.0, opacity)) # Clamp opacity between 0 and 1
        
        # Use copies to avoid modifying the original asset for subsequent bars
        bg_copy = apply_opacity(bar_bg.copy(), alpha_factor)
        left_copy = apply_opacity(bar_left.copy(), alpha_factor)
        right_copy = apply_opacity(bar_right.copy(), alpha_factor)

        # 4. Draw Background
        base_img.paste(bg_copy, (cap_width, 0), bg_copy)
        base_img.paste(left_copy, (0, 0), left_copy)
        base_img.paste(right_copy, (bar_width - cap_width, 0), right_copy)
        
        # 5. Calculate Fill Bar Dimensions
        fill_width = int((bar_width - 2 * cap_width) * hp_percent)
        fill_x_start = cap_width
        
        if fill_width > 0:
            # The fill image should be the full height of the bar
            fill_height = fill_img.height
            
            # Create a cropped version of the fill image to the required width and height
            scaled_fill_img = fill_img.resize((fill_width, fill_height), Image.Resampling.LANCZOS)
            
            # Apply opacity to the fill copy
            fill_copy = apply_opacity(scaled_fill_img.copy(), alpha_factor)
            
            # 6. Paste the Fill Bar
            base_img.paste(fill_copy, (fill_x_start, 0), fill_copy)
        
        # 7. Draw Text (Name/HP)
        font_size = int(self.current_settings.get('default_font_size', 18) * self.current_settings.get('text_scale', 1.0))
        font_name = self.current_settings.get('default_font', 'arial.ttf')
        font = self.get_font(font_name, font_size)
        
        draw = ImageDraw.Draw(base_img)
        
        # Calculate text position (centered above the bar)
        text_w, text_h = draw.textsize(name, font=font)
        text_x = bar_width // 2
        text_y = -text_h - 2 # 2 pixels padding above the bar

        # Text color (White) with opacity
        text_alpha = int(255 * max(0.0, min(1.0, text_opacity)))
        draw.text(
            (text_x, text_y), 
            name, 
            fill=(255, 255, 255, text_alpha), 
            font=font, 
            anchor="mm" # Anchor the text to its middle-center for easy positioning
        )
        
        # 8. Convert to Tkinter PhotoImage and Draw to Canvas
        tk_img = ImageTk.PhotoImage(base_img)
        
        # Apply offsets from settings
        x_offset = self.current_settings.get('x_offset', 0)
        y_offset = self.current_settings.get('y_offset', 0)
        
        final_x = x + x_offset
        final_y = y + y_offset

        # Store the PhotoImage reference on the canvas item for garbage collection prevention
        item_id = self.canvas.create_image(final_x, final_y, image=tk_img, anchor=tk.NW)
        self.canvas.itemconfig(item_id, image=tk_img)
        self.canvas.images.append(tk_img) # Keep a reference to prevent garbage collection

    def update_bars(self, game_data):
        """Processes game data and draws all health bars."""
        if self.error_occurred:
            return

        # Clear the canvas of old drawings
        self.canvas.delete("all")
        
        # List to hold PhotoImage references to prevent garbage collection
        self.canvas.images = []

        try:
            for draw_item in game_data:
                # Ensure all necessary keys exist with defaults
                hp_percent = max(0.0, min(1.0, draw_item.get('hp_percent', 0.0)))
                fill_type = draw_item.get('type', 'normal')
                
                # Check for critical status
                is_crit = draw_item.get('is_crit', False) 
                
                # Check for boss status
                is_boss = draw_item.get('is_boss', False) 

                self.draw_bar(x=draw_item['x'], 
                            y=draw_item['y'], 
                            hp_percent=hp_percent, 
                            fill_type=fill_type, 
                            name=draw_item['name'],
                            is_boss=is_boss,
                            is_crit=is_crit,
                            opacity=self.current_settings.get('bar_opacity', 0.8),
                            text_opacity=self.current_settings.get('text_opacity', 1.0))

        except Exception as e:
            self.log_error(f"Error during update_bars: {e}")
            self.error_occurred = True
            self.error_message = f"Rendering Error! See {os.path.basename(ERROR_LOG_FILE)}."
            self.display_error_on_canvas()


    def update_loop(self):
        """
        The main loop that continuously loads game data and updates the display.
        It now also periodically reloads settings to apply external changes.
        """
        if self.error_occurred:
            # If an error occurred, keep displaying the error message
            self.root.after(UPDATE_INTERVAL, self.update_loop)
            return

        try:
            self.load_settings() # Reload settings to pick up external changes
            game_data = self.load_game_data()
            self.update_bars(game_data)
        except Exception as e:
            self.log_error(f"Error in update_loop: {e}")
            self.error_occurred = True
            self.error_message = f"Update Loop Error! See {os.path.basename(ERROR_LOG_FILE)}."
            self.display_error_on_canvas()
            
        self.root.after(UPDATE_INTERVAL, self.update_loop)

def main():
    """
    Initializes the Tkinter root window and starts the application.
    """
    root = tk.Tk()
    app = OverlayApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
