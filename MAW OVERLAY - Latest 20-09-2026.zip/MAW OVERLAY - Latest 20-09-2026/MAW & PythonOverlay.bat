@echo off

REM Launch the overlay in a new console window (visible)
start "" python "C:\GOG Games\Might & Magic MAW - Latest\_Python Overlay\overlay.py"

REM Wait 1 second to ensure the overlay starts
timeout /t 1 >nul

REM Launch the game
start "" "C:\GOG Games\Might & Magic MAW - Latest\mm8.exe"
