import tkinter as tk
from tkinter import colorchooser, font
import json
import os
import sys

# Determine the directory where the settings script is located
SCRIPT_DIR = os.path.dirname(os.path.abspath(sys.argv[0]))
SETTINGS_FILE = os.path.join(SCRIPT_DIR, "overlay_settings.json")
FONTS_DIR = os.path.join(SCRIPT_DIR, "fonts") # Path to the fonts subdirectory

# Default values for settings (must match those in overlay.py for consistency)
DEFAULT_FONT_FILE = "DefaultFont.ttf"
DEFAULT_TEXT_COLOR = (225, 225, 225, 255) # RGBA
DEFAULT_DEAD_TEXT_COLOR = (255, 0, 0, 255) # RGBA
DEFAULT_FONT_SIZE = 18
DEFAULT_TEXT_OUTLINE_WIDTH = 1
DEFAULT_TEXT_OUTLINE_COLOR = (0, 0, 0, 255) # RGBA
DEFAULT_USE_TEXT_BACKGROUND = True

# Default values for bar settings
DEFAULT_BASE_HEIGHT = 10
DEFAULT_LEFT_CAP_WIDTH = 5
DEFAULT_RIGHT_CAP_WIDTH = 5
DEFAULT_FILL_HEIGHT = 6
DEFAULT_BOSS_ICON_BASE_SIZE = 30 # New default for boss icon size
DEFAULT_CLOSE_RANGE_THRESHOLD = 400
DEFAULT_SHORTEN_NUMBER_DIGITS = 3 # New: for shortening HP numbers (e.g., 1000 -> 1K)

class SettingsApp:
    def __init__(self, master):
        self.master = master
        master.title("Overlay Settings")
        master.geometry("400x750") # Increased height to accommodate new setting
        master.resizable(False, False) # Make window not resizable

        self.settings = self.load_settings()

        self.create_widgets()
        self.apply_settings_to_widgets() # Apply loaded settings to widgets on startup

    def load_settings(self):
        """Loads settings from JSON file or returns defaults if file is not found/invalid."""
        try:
            if os.path.exists(SETTINGS_FILE):
                with open(SETTINGS_FILE, "r") as f:
                    settings = json.load(f)
                    # Ensure all default keys exist, add if missing
                    default_settings = self.get_default_settings()
                    for key, default_value in default_settings.items():
                        if key not in settings:
                            settings[key] = default_value
                    return settings
            else:
                return self.get_default_settings()
        except (json.JSONDecodeError, IOError) as e:
            print(f"Error loading settings: {e}. Using default settings.")
            return self.get_default_settings()

    def get_default_settings(self):
        """Returns a dictionary of default settings."""
        return {
            "font_file": DEFAULT_FONT_FILE,
            "font_size": DEFAULT_FONT_SIZE,
            "text_color": list(DEFAULT_TEXT_COLOR),
            "text_outline_width": DEFAULT_TEXT_OUTLINE_WIDTH,
            "text_outline_color": list(DEFAULT_TEXT_OUTLINE_COLOR),
            "use_text_background": DEFAULT_USE_TEXT_BACKGROUND,
            "base_height": DEFAULT_BASE_HEIGHT,
            "left_cap_width": DEFAULT_LEFT_CAP_WIDTH,
            "right_cap_width": DEFAULT_RIGHT_CAP_WIDTH,
            "fill_height": DEFAULT_FILL_HEIGHT,
            "boss_icon_base_size": DEFAULT_BOSS_ICON_BASE_SIZE,
            "close_range_threshold": DEFAULT_CLOSE_RANGE_THRESHOLD,
            "shorten_number_digits": DEFAULT_SHORTEN_NUMBER_DIGITS # New
        }

    def save_settings(self):
        """Saves current settings to JSON file."""
        current_settings = {
            "font_file": self.font_file_var.get(),
            "font_size": self.font_size_var.get(),
            "text_color": self.text_color_rgb,
            "text_outline_width": self.text_outline_width_var.get(),
            "text_outline_color": self.text_outline_color_rgb,
            "use_text_background": self.use_text_background_var.get(),
            "base_height": self.base_height_var.get(),
            "left_cap_width": self.left_cap_width_var.get(),
            "right_cap_width": self.right_cap_width_var.get(),
            "fill_height": self.fill_height_var.get(),
            "boss_icon_base_size": self.boss_icon_base_size_var.get(),
            "close_range_threshold": self.close_range_threshold_var.get(),
            "shorten_number_digits": self.shorten_number_digits_var.get() # New
        }
        try:
            # Ensure the directory exists before writing
            os.makedirs(os.path.dirname(SETTINGS_FILE), exist_ok=True)
            with open(SETTINGS_FILE, "w") as f:
                json.dump(current_settings, f, indent=4)
        except IOError as e:
            print(f"Error saving settings: {e}")

    def update_live_overlay(self, *args):
        """Called when a setting is changed to immediately save and update."""
        self.save_settings()

    def choose_font(self):
        """Opens a dialog to choose a font file."""
        font_files = [f for f in os.listdir(FONTS_DIR) if f.lower().endswith(('.ttf', '.otf'))]
        
        if not font_files:
            tk.messagebox.showwarning("No Fonts Found", f"No .ttf or .otf font files found in '{FONTS_DIR}'. Please add font files to this directory.")
            return

        top = tk.Toplevel(self.master)
        top.title("Select Font")
        
        listbox_frame = tk.Frame(top)
        listbox_frame.pack(padx=10, pady=10, fill="both", expand=True)

        scrollbar = tk.Scrollbar(listbox_frame, orient="vertical")
        listbox = tk.Listbox(listbox_frame, yscrollcommand=scrollbar.set)
        scrollbar.config(command=listbox.yview)
        scrollbar.pack(side="right", fill="y")
        listbox.pack(side="left", fill="both", expand=True)

        for f_name in font_files:
            listbox.insert(tk.END, f_name)
        
        try:
            current_font_index = font_files.index(self.font_file_var.get())
            listbox.selection_set(current_font_index)
            listbox.see(current_font_index) # Scroll to selected item
        except ValueError:
            pass

        def on_select():
            selected_index = listbox.curselection()
            if selected_index:
                selected_font = listbox.get(selected_index[0])
                self.font_file_var.set(selected_font)
                self.update_live_overlay()
            top.destroy()

        select_button = tk.Button(top, text="Select", command=on_select)
        select_button.pack(pady=5)

    def choose_color(self, color_var, color_display_label, is_outline=False):
        """Opens color picker and updates color variable and display."""
        initial_color = self.rgb_to_hex(color_var) if isinstance(color_var, list) else "#FFFFFF"
        color_code = colorchooser.askcolor(initialcolor=initial_color)
        if color_code[1]: # color_code[1] is the hex string
            rgb = color_code[0] # rgb is (R, G, B) tuple
            new_color_rgba = [int(c) for c in rgb] + [255]
            
            if is_outline:
                self.text_outline_color_rgb = new_color_rgba
            else:
                self.text_color_rgb = new_color_rgba
            
            color_display_label.config(bg=color_code[1])
            self.update_live_overlay()

    def rgb_to_hex(self, rgb_list):
        """Converts an RGB(A) list to a hex color string."""
        if len(rgb_list) == 4:
            rgb_list = rgb_list[:3]
        return f"#{rgb_list[0]:02x}{rgb_list[1]:02x}{rgb_list[2]:02x}"

    def apply_settings_to_widgets(self):
        """Applies the current settings (from self.settings) to all GUI widgets."""
        self.font_file_var.set(self.settings["font_file"])
        self.font_size_var.set(self.settings["font_size"])
        self.text_color_rgb = list(self.settings["text_color"]) # Ensure it's a list for mutability
        self.text_outline_width_var.set(self.settings["text_outline_width"])
        self.text_outline_color_rgb = list(self.settings["text_outline_color"]) # Ensure it's a list
        self.use_text_background_var.set(self.settings["use_text_background"])
        
        self.base_height_var.set(self.settings["base_height"])
        self.left_cap_width_var.set(self.settings["left_cap_width"])
        self.right_cap_width_var.set(self.settings["right_cap_width"])
        self.fill_height_var.set(self.settings["fill_height"])
        self.boss_icon_base_size_var.set(self.settings["boss_icon_base_size"])
        self.close_range_threshold_var.set(self.settings["close_range_threshold"])
        self.shorten_number_digits_var.set(self.settings["shorten_number_digits"]) # New

        # Update color preview labels
        self.text_color_display.config(bg=self.rgb_to_hex(self.text_color_rgb))
        self.text_outline_color_display.config(bg=self.rgb_to_hex(self.text_outline_color_rgb))

    def restore_defaults(self):
        """Restores all settings to their default values."""
        confirm = tk.messagebox.askyesno("Restore Defaults", "Are you sure you want to restore all settings to their default values?")
        if confirm:
            self.settings = self.get_default_settings()
            self.apply_settings_to_widgets() # Update GUI
            self.save_settings() # Save defaults to file
            tk.messagebox.showinfo("Defaults Restored", "All settings have been restored to defaults.")


    def create_widgets(self):
        """Creates all UI widgets for settings."""
        # Font Settings
        font_settings_frame = tk.LabelFrame(self.master, text="Font Settings")
        font_settings_frame.pack(padx=10, pady=5, fill="x")

        self.font_file_var = tk.StringVar() # Initialized later in apply_settings_to_widgets
        tk.Label(font_settings_frame, text="Font File:").grid(row=0, column=0, sticky="w")
        tk.Entry(font_settings_frame, textvariable=self.font_file_var, state="readonly", width=30).grid(row=0, column=1, sticky="ew", padx=2, pady=2)
        tk.Button(font_settings_frame, text="Browse", command=self.choose_font).grid(row=0, column=2, sticky="e")

        self.font_size_var = tk.IntVar() # Initialized later
        tk.Label(font_settings_frame, text="Font Size:").grid(row=1, column=0, sticky="w")
        tk.Scale(font_settings_frame, from_=8, to=48, orient="h", variable=self.font_size_var, command=self.update_live_overlay).grid(row=1, column=1, columnspan=2, sticky="ew")

        # Text Color Settings
        text_color_frame = tk.LabelFrame(self.master, text="Text Color Settings")
        text_color_frame.pack(padx=10, pady=5, fill="x")

        # Main Text Color
        self.text_color_rgb = [] # Initialized later in apply_settings_to_widgets
        tk.Label(text_color_frame, text="Text Color:").grid(row=0, column=0, sticky="w")
        self.text_color_display = tk.Label(text_color_frame, width=5, relief="sunken") # Color set later
        self.text_color_display.grid(row=0, column=1, padx=5, pady=2, sticky="ew")
        tk.Button(text_color_frame, text="Choose", command=lambda: self.choose_color(self.text_color_rgb, self.text_color_display, False)).grid(row=0, column=2, sticky="e")

        # Text Outline Width
        self.text_outline_width_var = tk.IntVar() # Initialized later
        tk.Label(text_color_frame, text="Outline Width:").grid(row=1, column=0, sticky="w")
        tk.Scale(text_color_frame, from_=0, to=5, orient="h", variable=self.text_outline_width_var, command=self.update_live_overlay).grid(row=1, column=1, columnspan=2, sticky="ew")

        # Text Outline Color
        self.text_outline_color_rgb = [] # Initialized later
        tk.Label(text_color_frame, text="Outline Color:").grid(row=2, column=0, sticky="w")
        self.text_outline_color_display = tk.Label(text_color_frame, width=5, relief="sunken") # Color set later
        self.text_outline_color_display.grid(row=2, column=1, padx=5, pady=2, sticky="ew")
        tk.Button(text_color_frame, text="Choose", command=lambda: self.choose_color(self.text_outline_color_rgb, self.text_outline_color_display, True)).grid(row=2, column=2, sticky="e")

        # Use Text Background checkbox
        self.use_text_background_var = tk.BooleanVar() # Initialized later
        tk.Checkbutton(text_color_frame, text="Use Text Background", variable=self.use_text_background_var, command=self.update_live_overlay).grid(row=3, column=0, columnspan=3, sticky="w")

        # Bar Dimensions Settings
        bar_settings_frame = tk.LabelFrame(self.master, text="Bar Dimensions")
        bar_settings_frame.pack(padx=10, pady=5, fill="x")

        self.base_height_var = tk.IntVar() # Initialized later
        tk.Label(bar_settings_frame, text="Base Height:").grid(row=0, column=0, sticky="w")
        tk.Scale(bar_settings_frame, from_=5, to=50, orient="h", variable=self.base_height_var, command=self.update_live_overlay).grid(row=0, column=1, sticky="ew")

        self.left_cap_width_var = tk.IntVar() # Initialized later
        tk.Label(bar_settings_frame, text="Left Cap Width:").grid(row=1, column=0, sticky="w")
        tk.Scale(bar_settings_frame, from_=0, to=20, orient="h", variable=self.left_cap_width_var, command=self.update_live_overlay).grid(row=1, column=1, sticky="ew")

        self.right_cap_width_var = tk.IntVar() # Initialized later
        tk.Label(bar_settings_frame, text="Right Cap Width:").grid(row=2, column=0, sticky="w")
        tk.Scale(bar_settings_frame, from_=0, to=20, orient="h", variable=self.right_cap_width_var, command=self.update_live_overlay).grid(row=2, column=1, sticky="ew")

        self.fill_height_var = tk.IntVar() # Initialized later
        tk.Label(bar_settings_frame, text="Fill Height:").grid(row=3, column=0, sticky="w")
        tk.Scale(bar_settings_frame, from_=1, to=40, orient="h", variable=self.fill_height_var, command=self.update_live_overlay).grid(row=3, column=1, sticky="ew")

        # New: Boss Icon Size
        self.boss_icon_base_size_var = tk.IntVar() # Initialized later
        tk.Label(bar_settings_frame, text="Boss Icon Size:").grid(row=5, column=0, sticky="w")
        tk.Scale(bar_settings_frame, from_=10, to=100, orient="h", variable=self.boss_icon_base_size_var, command=self.update_live_overlay).grid(row=5, column=1, sticky="ew")

        # Close Range Threshold
        close_range_frame = tk.LabelFrame(self.master, text="Close Range Stacking")
        close_range_frame.pack(padx=10, pady=5, fill="x")

        self.close_range_threshold_var = tk.IntVar() # Initialized later
        tk.Label(close_range_frame, text="Threshold Distance (0=Off):").grid(row=0, column=0, sticky="w")
        tk.Scale(close_range_frame, from_=0, to=1000, orient="h", variable=self.close_range_threshold_var, command=self.update_live_overlay).grid(row=0, column=1, sticky="ew")

        # Number Shortening Settings
        shortening_frame = tk.LabelFrame(self.master, text="Number Shortening")
        shortening_frame.pack(padx=10, pady=5, fill="x")

        self.shorten_number_digits_var = tk.IntVar() # Initialized later
        tk.Label(shortening_frame, text="Shortening Digits (for K/M/B thresholds):").grid(row=0, column=0, sticky="w")
        tk.Scale(shortening_frame, from_=1, to=10, orient="h", variable=self.shorten_number_digits_var, command=self.update_live_overlay).grid(row=0, column=1, sticky="ew")


        # Make columns expandable
        font_settings_frame.grid_columnconfigure(1, weight=1)
        text_color_frame.grid_columnconfigure(1, weight=1)
        bar_settings_frame.grid_columnconfigure(1, weight=1)
        close_range_frame.grid_columnconfigure(1, weight=1)
        shortening_frame.grid_columnconfigure(1, weight=1) # New

        # Restore Defaults Button
        restore_button = tk.Button(self.master, text="Restore Defaults", command=self.restore_defaults)
        restore_button.pack(pady=10)

        # Ensure settings are saved on window close
        self.master.protocol("WM_DELETE_WINDOW", self.on_closing)

    def on_closing(self):
        self.save_settings()
        self.master.destroy()

def main():
    root = tk.Tk()
    app = SettingsApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
