import json
import tkinter as tk
from PIL import Image, ImageTk, ImageFont, ImageDraw
import re
import os
import sys
import time
import math
import traceback # Import traceback for detailed error logging

# --- Configuration ---
SCRIPT_DIR = os.path.dirname(os.path.abspath(sys.argv[0]))
MONSTER_FILE = os.path.join(SCRIPT_DIR, "visible_monsters.json") 
UPDATE_INTERVAL = 10  # milliseconds (how often to refresh the overlay)
SETTINGS_FILE = os.path.join(SCRIPT_DIR, "overlay_settings.json") # Path to the settings file
FONTS_DIR = os.path.join(SCRIPT_DIR, "fonts") # Path to the fonts subdirectory
BOSS_ICONS_DIR = os.path.join(SCRIPT_DIR, "boss icons") # Path to the boss icons subdirectory
ERROR_LOG_FILE = os.path.join(SCRIPT_DIR, "overlay_error.log") # New: Path for error log file

ASSET_DIR = SCRIPT_DIR # Assuming assets are in the same directory as the script
BACKGROUND_PATH = os.path.join(ASSET_DIR, "background.png") # Main bar background
LEFT_CAP_PATH = os.path.join(ASSET_DIR, "left_cap.png")
RIGHT_CAP_PATH = os.path.join(ASSET_DIR, "right_cap.png")
FILL_PATHS = {
    "boss": os.path.join(ASSET_DIR, "fill_boss.png"),
    "50": os.path.join(ASSET_DIR, "fill_50.png"),
    "75": os.path.join(ASSET_DIR, "fill_75.png"),
    "default": os.path.join(ASSET_DIR, "fill.png"),
    "hit": os.path.join(ASSET_DIR, "fill_hit.png"),
    "crit": os.path.join(ASSET_DIR, "fill_crit.png"),
    "mouseover": os.path.join(ASSET_DIR, "fill_mouseover.png"),
    "dot_total": os.path.join(ASSET_DIR, "fill_dot_total.png"),
    "dot_tick": os.path.join(ASSET_DIR, "fill_dot_tick.png"),
    "boss_frame": os.path.join(ASSET_DIR, "boss_frame.png"), # Boss frame added
    "text_bg": os.path.join(ASSET_DIR, "text_bg.png") # text_bg for text background
}


_temp_root = tk.Tk()
_temp_root.withdraw()
detected_user_res_X = _temp_root.winfo_screenwidth()
detected_user_res_Y = _temp_root.winfo_screenheight()
_temp_root.destroy()

# Default values for settings (these will now be loaded from or saved to the settings file)
DEFAULT_FONT_FILE = "DefaultFont.ttf" # Must match in settings GUI
DEFAULT_TEXT_COLOR = (225, 225, 225, 255)
DEFAULT_DEAD_TEXT_COLOR = (255, 0, 0, 255)
DEFAULT_FONT_SIZE = 18 
DEFAULT_TEXT_OUTLINE_WIDTH = 1
DEFAULT_TEXT_OUTLINE_COLOR = (0, 0, 0, 255)
DEFAULT_USE_TEXT_BACKGROUND = True

# New adjustable bar settings
DEFAULT_BASE_HEIGHT = 10
DEFAULT_LEFT_CAP_WIDTH = 5
DEFAULT_RIGHT_CAP_WIDTH = 5
DEFAULT_FILL_HEIGHT = 6
DEFAULT_BOSS_FRAME_BASE_WIDTH = 40 # Default width for the boss frame
DEFAULT_BOSS_FRAME_BASE_HEIGHT = 40 # Default height for the boss frame
DEFAULT_BOSS_ICON_BASE_SIZE = 30 # Default size for the dynamic boss icons
DEFAULT_CLOSE_RANGE_THRESHOLD = 400 # 0 means off
DEFAULT_SHORTEN_NUMBER_DIGITS = 3 # New: for shortening HP numbers (e.g., 1000 -> 1K)


ENABLE_SCALING = True
SCALE_NEAR = 1.2
SCALE_FAR = 0.6
SCALE_NEAR_DIST = 1000
SCALE_FAR_DIST = 5000

# Updated BOSS_PREFIXES list (used for logic, not for direct paths anymore)
BOSS_PREFIXES = (
    "Venomous", "Leech", "Explosion", "Adamantite", "Puller",
    "Summoner", "Swift", "Regenerating", "Reflecting", "Thorn",
    "Swapper", "Fixator", "Plagueborn", "Broodlord", "Omnipotent"
)

# New: Mapping from boss prefix to icon filename
BOSS_ICON_MAPPING = {
    "Venomous": "boss_icon_venomous.png",
    "Leech": "boss_icon_leech.png",
    "Explosion": "boss_icon_explosion.png",
    "Adamantite": "boss_icon_adamantite.png",
    "Puller": "boss_icon_puller.png",
    "Summoner": "boss_icon_summoner.png",
    "Swift": "boss_icon_swift.png",
    "Regenerating": "boss_icon_regenerating.png",
    "Reflecting": "boss_icon_reflecting.png",
    "Thorn": "boss_icon_thorn.png",
    "Swapper": "boss_icon_swapper.png",
    "Fixator": "boss_icon_fixator.png",
    "Plagueborn": "boss_icon_plagueborn.png",
    "Broodlord": "boss_icon_broodlord.png",
    "Omnipotent": "boss_icon_omnipotent.png"
}

CLOSE_STACK_X = (detected_user_res_X / 2) - 0
CLOSE_STACK_START_Y = detected_user_res_Y - 320
CLOSE_STACK_SPACING = 50

OVERLAY_HIGHLIGHT_BORDER_PX = 1

SIMULATE_DOT_DATA = False
INITIAL_DOT_TOTAL_DAMAGE = 500
INITIAL_DOT_TICK_DAMAGE = 50
INITIAL_DOT_DURATION = 5

FADE_OUT_DURATION = 0.8


class OverlayApp:
    def __init__(self, root):
        self.root = root
        root.title("Monster HP Overlay")

        transparent_color = "#245132"
        root.overrideredirect(True)
        root.config(bg=transparent_color)
        root.attributes("-transparentcolor", transparent_color)
        root.attributes("-topmost", True)
        root.geometry(f"{detected_user_res_X}x{detected_user_res_Y}+0+0")

        self.canvas = tk.Canvas(root, width=detected_user_res_X, height=detected_user_res_Y,
                                bg=transparent_color, highlightthickness=0)
        self.canvas.pack()

        # Flag to indicate if an error occurred during initialization or update
        self.error_occurred = False 
        self.error_message = ""

        try:
            self.load_assets() # Load all image assets
            
            # Initialize properties to be updated by settings
            self.current_font_file = DEFAULT_FONT_FILE
            self.current_font_path = os.path.join(FONTS_DIR, DEFAULT_FONT_FILE)
            self.current_font_size = DEFAULT_FONT_SIZE
            self.current_text_color = DEFAULT_TEXT_COLOR
            self.current_text_outline_width = DEFAULT_TEXT_OUTLINE_WIDTH
            self.current_text_outline_color = DEFAULT_TEXT_OUTLINE_COLOR
            self.use_text_background = DEFAULT_USE_TEXT_BACKGROUND

            # Initialize new bar and number shortening settings
            self.base_height = DEFAULT_BASE_HEIGHT
            self.left_cap_width = DEFAULT_LEFT_CAP_WIDTH
            self.right_cap_width = DEFAULT_RIGHT_CAP_WIDTH
            self.fill_height = DEFAULT_FILL_HEIGHT
            self.boss_frame_base_width = DEFAULT_BOSS_FRAME_BASE_WIDTH
            self.boss_frame_base_height = DEFAULT_BOSS_FRAME_BASE_HEIGHT
            self.boss_icon_base_size = DEFAULT_BOSS_ICON_BASE_SIZE # Dynamic boss icon size
            self.close_range_threshold = DEFAULT_CLOSE_RANGE_THRESHOLD
            self.shorten_number_digits = DEFAULT_SHORTEN_NUMBER_DIGITS # New setting
            
            self.load_settings() # Load current settings from file and apply them

            self.tk_image_references = []
            self.game_targeted_monster_index = None

            self.simulated_dot_active_on_monster = None
            self.simulated_dot_start_time = None
            self.simulated_dot_total_remaining = 0
            self.simulated_dot_tick_remaining = 0

            self.fading_monsters = {}
            self.permanently_hidden_monsters = set()

            self.update_loop() # Start the main update loop
        except Exception as e:
            self.log_error(f"Error during OverlayApp initialization: {e}")
            self.error_occurred = True
            self.error_message = f"Initialization Error! See {os.path.basename(ERROR_LOG_FILE)} for details."
            self.display_error_on_canvas()


    def log_error(self, message):
        """Logs an error message and traceback to a file."""
        with open(ERROR_LOG_FILE, "a") as f:
            f.write(f"[{time.ctime()}] ERROR: {message}\n")
            f.write(traceback.format_exc()) # Write the full traceback
            f.write("-" * 50 + "\n")
        print(f"Error logged to {ERROR_LOG_FILE}") # Also print to console if running from terminal

    def display_error_on_canvas(self):
        """Displays a simple error message on the canvas."""
        self.canvas.delete("all") # Clear any existing drawings
        self.tk_image_references.clear()

        # Use a default font and size for the error message
        try:
            error_font = ImageFont.truetype(os.path.join(FONTS_DIR, DEFAULT_FONT_FILE), 24)
        except IOError:
            error_font = ImageFont.load_default()

        # Render the error message
        # Create a dummy image to draw text on for size calculation
        dummy_img = Image.new("RGBA", (1, 1), (0, 0, 0, 0))
        dummy_draw = ImageDraw.Draw(dummy_img)
        bbox = dummy_draw.textbbox((0,0), self.error_message, font=error_font)
        text_w = bbox[2] - bbox[0]
        text_h = bbox[3] - bbox[1]

        # Create the actual image for the error message
        error_img = Image.new("RGBA", (text_w + 20, text_h + 20), (0, 0, 0, 180)) # Semi-transparent black background
        error_draw = ImageDraw.Draw(error_img)
        error_draw.text((10, 10), self.error_message, font=error_font, fill=(255, 0, 0, 255)) # Red text

        error_tk_img = ImageTk.PhotoImage(error_img)
        self.tk_image_references.append(error_tk_img) # Keep reference

        # Display the error message in the center of the screen
        self.canvas.create_image(detected_user_res_X / 2, detected_user_res_Y / 2,
                                 image=error_tk_img, anchor="center")
        self.root.update_idletasks() # Force update

    def load_assets(self):
        # Load fixed assets
        try:
            self.bg_img_pil = Image.open(BACKGROUND_PATH)
        except FileNotFoundError:
            print(f"Error: Background image (background.png) not found at {BACKGROUND_PATH}. Overlay might not display correctly.")
            self.bg_img_pil = None

        try:
            self.left_cap_img_pil = Image.open(LEFT_CAP_PATH)
        except FileNotFoundError:
            print(f"Error: Left cap image not found at {LEFT_CAP_PATH}. Overlay might not display correctly.")
            self.left_cap_img_pil = None

        try:
            self.right_cap_img_pil = Image.open(RIGHT_CAP_PATH)
        except FileNotFoundError:
            print(f"Error: Right cap image not found at {RIGHT_CAP_PATH}. Overlay might not display correctly.")
            self.right_cap_img_pil = None

        self.fill_imgs_pil = {}
        for key, path in FILL_PATHS.items():
            if os.path.exists(path):
                self.fill_imgs_pil[key] = Image.open(path)
            else:
                print(f"Warning: Fill image '{key}' not found at '{path}'.")

        if "default" not in self.fill_imgs_pil:
            print("Error: Default fill image (fill.png) is missing. Health bars may not render.")
        if "hit" not in self.fill_imgs_pil:
            print("Warning: Hit indicator image (fill_hit.png) is missing. Last hit damage will not be displayed.")
        if "crit" not in self.fill_imgs_pil:
            print("Warning: Crit indicator image (fill_crit.png) is missing. Critical hit damage will not be displayed differently.")
        if "mouseover" not in self.fill_imgs_pil:
            print("Warning: Mouseover highlight image (fill_mouseover.png) is missing. Highlight will not be displayed.")
        if "dot_total" not in self.fill_imgs_pil:
            print("Warning: DoT total image (fill_dot_total.png) is missing. DoT total will not be displayed.")
        if "dot_tick" not in self.fill_imgs_pil:
            print("Warning: DoT tick image (fill_dot_tick.png) is missing. DoT tick will not be displayed.")
        if "boss_frame" not in self.fill_imgs_pil:
            print("Warning: Boss frame image (boss_frame.png) is missing. Boss health bars will not have a frame.")
        if "text_bg" not in self.fill_imgs_pil:
            print("Warning: Text background image (text_bg.png) is missing. Text will not have a dedicated background.")

        # New: Load all dynamic boss icons
        self.boss_icons_pil = {}
        os.makedirs(BOSS_ICONS_DIR, exist_ok=True) # Ensure the directory exists
        for prefix, filename in BOSS_ICON_MAPPING.items():
            path = os.path.join(BOSS_ICONS_DIR, filename)
            try:
                self.boss_icons_pil[prefix] = Image.open(path)
            except FileNotFoundError:
                print(f"Warning: Boss icon for '{prefix}' not found at '{path}'. This boss type will not have a unique icon.")
            except Exception as e:
                print(f"Error loading boss icon '{filename}': {e}")


    def load_settings(self):
        """
        Loads settings from the SETTINGS_FILE. If the file doesn't exist or is invalid,
        it initializes default settings and attempts to save them.
        """
        settings = {}
        try:
            if os.path.exists(SETTINGS_FILE):
                with open(SETTINGS_FILE, "r") as f:
                    settings = json.load(f)
        except json.JSONDecodeError:
            print(f"Warning: Settings file '{SETTINGS_FILE}' is corrupted. Using default settings.")
        except IOError as e:
            print(f"Error loading settings file '{SETTINGS_FILE}': {e}. Using default settings.")

        # Update instance variables with loaded settings or defaults
        self.current_font_file = settings.get("font_file", DEFAULT_FONT_FILE)
        self.current_font_size = settings.get("font_size", DEFAULT_FONT_SIZE)
        
        # Construct full path to font file
        self.current_font_path = os.path.join(FONTS_DIR, self.current_font_file)

        # Attempt to load the font with the new settings
        try:
            self.pil_font = ImageFont.truetype(self.current_font_path, self.current_font_size)
        except IOError:
            print(f"Error: Custom font '{self.current_font_file}' not found or invalid at '{self.current_font_path}'. Using default font and size.")
            self.pil_font = ImageFont.truetype(os.path.join(FONTS_DIR, DEFAULT_FONT_FILE), DEFAULT_FONT_SIZE)
            self.current_font_file = DEFAULT_FONT_FILE
            self.current_font_path = os.path.join(FONTS_DIR, DEFAULT_FONT_FILE)
            self.current_font_size = DEFAULT_FONT_SIZE
        except Exception as e:
            print(f"An unexpected error occurred while loading font: {e}. Using generic default font.")
            self.pil_font = ImageFont.load_default()
            self.current_font_file = DEFAULT_FONT_FILE # Ensure consistent state
            self.current_font_path = os.path.join(FONTS_DIR, DEFAULT_FONT_FILE)
            self.current_font_size = DEFAULT_FONT_SIZE

        self.current_text_color = tuple(settings.get("text_color", list(DEFAULT_TEXT_COLOR)))
        self.current_text_outline_width = settings.get("text_outline_width", DEFAULT_TEXT_OUTLINE_WIDTH)
        self.current_text_outline_color = tuple(settings.get("text_outline_color", list(DEFAULT_TEXT_OUTLINE_COLOR)))
        self.use_text_background = settings.get("use_text_background", DEFAULT_USE_TEXT_BACKGROUND)

        # Load new bar and number shortening settings
        self.base_height = settings.get("base_height", DEFAULT_BASE_HEIGHT)
        self.left_cap_width = settings.get("left_cap_width", DEFAULT_LEFT_CAP_WIDTH)
        self.right_cap_width = settings.get("right_cap_width", DEFAULT_RIGHT_CAP_WIDTH)
        self.fill_height = settings.get("fill_height", DEFAULT_FILL_HEIGHT)
        self.boss_frame_base_width = settings.get("boss_frame_base_width", DEFAULT_BOSS_FRAME_BASE_WIDTH)
        self.boss_frame_base_height = settings.get("boss_frame_base_height", DEFAULT_BOSS_FRAME_BASE_HEIGHT)
        self.boss_icon_base_size = settings.get("boss_icon_base_size", DEFAULT_BOSS_ICON_BASE_SIZE)
        self.close_range_threshold = settings.get("close_range_threshold", DEFAULT_CLOSE_RANGE_THRESHOLD)
        self.shorten_number_digits = settings.get("shorten_number_digits", DEFAULT_SHORTEN_NUMBER_DIGITS) # New setting

        # Save the settings back to ensure consistency (e.g., if defaults were applied)
        self.save_current_settings_to_file()

    def save_current_settings_to_file(self):
        """
        Saves the current overlay settings from instance variables to the SETTINGS_FILE.
        This is called by load_settings to ensure the file always reflects current state,
        especially if defaults were applied.
        """
        settings_to_save = {
            "font_file": self.current_font_file,
            "font_size": self.current_font_size,
            "text_color": list(self.current_text_color),
            "text_outline_width": self.current_text_outline_width,
            "text_outline_color": list(self.current_text_outline_color),
            "use_text_background": self.use_text_background,
            "base_height": self.base_height,
            "left_cap_width": self.left_cap_width,
            "right_cap_width": self.right_cap_width,
            "fill_height": self.fill_height,
            "boss_frame_base_width": self.boss_frame_base_width,
            "boss_frame_base_height": self.boss_frame_base_height,
            "boss_icon_base_size": self.boss_icon_base_size,
            "close_range_threshold": self.close_range_threshold,
            "shorten_number_digits": self.shorten_number_digits
        }
        try:
            os.makedirs(FONTS_DIR, exist_ok=True) # Ensure the fonts directory exists
            with open(SETTINGS_FILE, "w") as f:
                json.dump(settings_to_save, f, indent=4)
        except IOError as e:
            print(f"Error saving settings to '{SETTINGS_FILE}': {e}")
        except Exception as e:
            print(f"An unexpected error occurred while saving settings: {e}")


    def shorten_number(self, number, significant_digits):
        """
        Shortens a number with K, M, B suffixes based on magnitude.
        
        Args:
            number (int/float): The number to shorten.
            significant_digits (int): Influences the threshold for K/M/B.
                                    Must be at least 1.
        
        Returns:
            str: The shortened number string (e.g., "1.2K", "50M").
        """
        if significant_digits < 1:
            raise ValueError("Number of digits needs to be at least 1")

        suffix = ""
        divisor = 1.0

        threshold_adjust_power = max(0, significant_digits - 3)

        if abs(number) >= 10**(9 + threshold_adjust_power):
            suffix = "B"
            divisor = 1e9
        elif abs(number) >= 10**(6 + threshold_adjust_power):
            suffix = "M"
            divisor = 1e6
        elif abs(number) >= 10**(3 + threshold_adjust_power):
            suffix = "K"
            divisor = 1e3
        
        shortened = round(number / divisor)
        
        return f"{int(shortened)}{suffix}"

    def load_game_data(self):
        """
        Loads all game data (monsters, targeted monster, indoor status, players)
        from the JSON file.
        Returns a dictionary containing all parsed data.
        """
        try:
            with open(MONSTER_FILE, "r") as f:
                content = f.read().strip()
                if not content:
                    return {} # Return empty dict if file is empty
                data = json.loads(content)
                
                # Simulate DoT data if enabled
                if SIMULATE_DOT_DATA:
                    current_time = time.time()
                    monsters = data.get("Monsters", [])
                    targeted_index = data.get("TargetedMonsterIndex")

                    targeted_mon_data = None
                    for mon in monsters:
                        if mon.get("Index") == targeted_index:
                            targeted_mon_data = mon
                            break

                    if targeted_index is None:
                        self.simulated_dot_active_on_monster = None
                        self.simulated_dot_start_time = None
                        self.simulated_dot_total_remaining = 0
                        self.simulated_dot_tick_remaining = 0
                    elif targeted_index != self.simulated_dot_active_on_monster or self.simulated_dot_start_time is None:
                        if targeted_mon_data and targeted_mon_data.get("HP", 0) > 0:
                            self.simulated_dot_active_on_monster = targeted_index
                            self.simulated_dot_start_time = current_time
                            self.simulated_dot_total_remaining = INITIAL_DOT_TOTAL_DAMAGE
                            self.simulated_dot_tick_remaining = INITIAL_DOT_TICK_DAMAGE
                        else:
                            self.simulated_dot_active_on_monster = None
                            self.simulated_dot_start_time = None
                            self.simulated_dot_total_remaining = 0
                            self.simulated_dot_tick_remaining = 0

                    if self.simulated_dot_active_on_monster == targeted_index and self.simulated_dot_start_time is not None:
                        elapsed_time = current_time - self.simulated_dot_start_time
                        
                        if elapsed_time >= INITIAL_DOT_DURATION:
                            self.simulated_dot_total_remaining = 0
                            self.simulated_dot_tick_remaining = 0
                            self.simulated_dot_active_on_monster = None
                            self.simulated_dot_start_time = None
                        else:
                            ticks_passed = math.floor(elapsed_time)
                            self.simulated_dot_total_remaining = max(0, INITIAL_DOT_TOTAL_DAMAGE - (ticks_passed * INITIAL_DOT_TICK_DAMAGE))
                            
                            if self.simulated_dot_total_remaining > 0:
                                self.simulated_dot_tick_remaining = INITIAL_DOT_TICK_DAMAGE
                            else:
                                self.simulated_dot_tick_remaining = 0

                        if targeted_mon_data:
                            targeted_mon_data["TotalDotDamage"] = self.simulated_dot_total_remaining
                            targeted_mon_data["DotTickDamage"] = self.simulated_dot_tick_remaining
                            
                    # Update the data dictionary with simulated values
                    data["Monsters"] = monsters

                return data
        except FileNotFoundError:
            if SIMULATE_DOT_DATA:
                dummy_monsters = [{
                    "Index": 999,
                    "Name": "Simulated Monster",
                    "HP": 750,
                    "FullHP": 1000,
                    "Distance": 1500,
                    "ScreenX": detected_user_res_X // 2,
                    "ScreenY": detected_user_res_Y // 2,
                    "BarSize": 250,
                    "LastHitDamage": 50
                }]
                self.simulated_dot_active_on_monster = dummy_monsters[0]["Index"]
                self.simulated_dot_start_time = time.time()
                self.simulated_dot_total_remaining = INITIAL_DOT_TOTAL_DAMAGE
                self.simulated_dot_tick_remaining = INITIAL_DOT_TICK_DAMAGE

                dummy_monsters[0]["TotalDotDamage"] = self.simulated_dot_total_remaining
                dummy_monsters[0]["DotTickDamage"] = self.simulated_dot_tick_remaining
                
                return {
                    "Monsters": dummy_monsters,
                    "TargetedMonsterIndex": dummy_monsters[0]["Index"],
                    "IsIndoor": False,
                    "Players": [] # No player data simulation in this reverted state
                }
            # Suppress print for FileNotFoundError if not simulating, as it's expected at startup
            return {}
        except json.JSONDecodeError as e:
            self.log_error(f"Error decoding JSON from {MONSTER_FILE}: {e}")
            self.error_occurred = True
            self.error_message = f"Data File Error! See {os.path.basename(ERROR_LOG_FILE)}."
            return {}
        except Exception as e:
            self.log_error(f"An unexpected error occurred while loading game data: {e}")
            self.error_occurred = True
            self.error_message = f"Data Load Error! See {os.path.basename(ERROR_LOG_FILE)}."
            return {}

    def get_scale(self, distance):
        """
        Calculates the scaling factor for health bars based on monster distance.
        """
        if not ENABLE_SCALING:
            return 1.0
        elif distance <= SCALE_NEAR_DIST:
            return SCALE_NEAR
        elif distance >= SCALE_FAR_DIST:
            return SCALE_FAR
        else:
            t = (distance - SCALE_NEAR_DIST) / (SCALE_FAR_DIST - SCALE_NEAR_DIST)
            return SCALE_NEAR + t * (SCALE_FAR - SCALE_NEAR)

    def get_boss_prefix(self, name):
        """
        Checks if a monster's name starts with a known boss prefix and returns it.
        """
        for prefix in BOSS_PREFIXES:
            if name.startswith(prefix):
                return prefix
        return None

    def render_text(self, text, color=None, opacity=255, background_image_pil=None, bg_opacity=255):
        """
        Renders text onto a transparent PIL Image with an outline and optional background image.
        Uses current settings from the OverlayApp instance for font, size, outline, and text_bg.
        """
        current_text_color = color if color is not None else self.current_text_color 
        outline_color = self.current_text_outline_color
        outline_width = self.current_text_outline_width
        
        # Ensure colors are RGBA tuples
        if len(current_text_color) == 3:
            current_text_color = (current_text_color[0], current_text_color[1], current_text_color[2], 255)
        if len(outline_color) == 3:
            outline_color = (outline_color[0], outline_color[1], outline_color[2], 255)

        # Get text bounding box (left, top, right, bottom relative to origin if drawn at 0,0)
        bbox = self.pil_font.getbbox(text)
        
        # Calculate content dimensions ensuring all parts of the font are included
        content_w = bbox[2] - bbox[0] + outline_width * 2
        content_h = bbox[3] - bbox[1] + outline_width * 2

        # Add extra padding for the background image
        bg_pad_x = 4
        bg_pad_y = 2
        
        # Ensure minimum 1 pixel to avoid errors with empty or extremely small images
        final_img_w = max(1, content_w + bg_pad_x * 2) 
        final_img_h = max(1, content_h + bg_pad_y * 2) 

        # Create the base image for text content (transparent)
        text_content_img = Image.new("RGBA", (content_w, content_h), (0, 0, 0, 0))
        draw_content = ImageDraw.Draw(text_content_img)

        # Calculate text drawing position within text_content_img
        text_draw_x = outline_width - bbox[0]
        text_draw_y = outline_width - bbox[1]

        # Draw outline
        for x_offset in range(-outline_width, outline_width + 1):
            for y_offset in range(-outline_width, outline_width + 1):
                if x_offset == 0 and y_offset == 0:
                    continue 
                draw_content.text((text_draw_x + x_offset, text_draw_y + y_offset), text,
                                  font=self.pil_font, fill=outline_color)

        # Draw the main text on top
        draw_content.text((text_draw_x, text_draw_y), text,
                          font=self.pil_font, fill=current_text_color)

        # Apply opacity to the text content
        if opacity < 255:
            current_alpha_text = text_content_img.split()[-1]
            new_alpha_text = current_alpha_text.point(lambda p: p * (opacity / 255.0))
            text_content_img.putalpha(new_alpha_text)

        # Create the final image which might contain the background
        final_img = Image.new("RGBA", (final_img_w, final_img_h), (0, 0, 0, 0))

        # Draw background image if provided and self.use_text_background is True
        if self.use_text_background and background_image_pil:
            scaled_bg = background_image_pil.resize((final_img_w, final_img_h), Image.LANCZOS)
            
            # Apply opacity to background as well
            if bg_opacity < 255: 
                if scaled_bg.mode != 'RGBA':
                    scaled_bg = scaled_bg.convert('RGBA')
                alpha_bg = scaled_bg.split()[-1]
                new_alpha_bg = alpha_bg.point(lambda p: p * (bg_opacity / 255.0))
                scaled_bg.putalpha(new_alpha_bg)
            
            final_img.paste(scaled_bg, (0, 0), scaled_bg) # Paste with alpha mask

        # Paste the text content onto the final image with padding
        final_img.paste(text_content_img, (bg_pad_x, bg_pad_y), text_content_img)

        tk_img = ImageTk.PhotoImage(final_img)
        self.tk_image_references.append(tk_img)
        return tk_img

    def _get_tk_image(self, pil_image_source, target_width, target_height, opacity=255):
        """
        Helper to resize a PIL Image and apply opacity, then convert to ImageTk.PhotoImage.
        """
        if pil_image_source is None:
            return None

        # Ensure target_width and target_height are at least 1 to avoid errors with empty images
        target_width = max(1, target_width)
        target_height = max(1, target_height)

        resized_img = pil_image_source.resize((target_width, target_height), Image.LANCZOS)

        if opacity < 255:
            if resized_img.mode in ('RGBA', 'LA') or (resized_img.mode == 'P' and 'transparency' in resized_img.info):
                alpha = resized_img.split()[-1]
            else:
                alpha = Image.new('L', resized_img.size, 255)

            alpha = alpha.point(lambda p: p * (opacity / 255.0))
            
            if resized_img.mode != 'RGBA':
                resized_img = resized_img.convert('RGBA')

            resized_img.putalpha(alpha)

        tk_img = ImageTk.PhotoImage(resized_img)
        self.tk_image_references.append(tk_img)
        return tk_img


    def draw_bar(self, mon, is_targeted=False, bar_opacity=255, text_opacity=255):
        """
        Draws a single monster's health bar and name on the canvas,
        including a visual indicator for the last hit damage, "Dead" text,
        optional game-targeted highlight, DoT indicators, and overall bar opacity.
        """
        hp = mon.get("HP", 1)
        full_hp = mon.get("FullHP", 1)
        name = mon.get("Name", "Unknown")
        x = mon.get("ScreenX", detected_user_res_X // 2)
        y = mon.get("ScreenY", detected_user_res_Y // 2)
        dist = mon.get("Distance", 1000)
        bar_base_width = mon.get("BarSize", 200)
        last_hit_damage = mon.get("LastHitDamage", 0)
        is_crit = mon.get("IsCrit", False)
        
        total_dot_damage = mon.get("TotalDotDamage", 0)
        dot_tick_damage = mon.get("DotTickDamage", 0)

        if full_hp == 0:
            full_hp = 1
        
        current_hp_ratio = max(0, min(1, hp / full_hp))
        
        prev_hp = min(full_hp, hp + last_hit_damage)
        prev_hp_ratio = max(0, min(1, prev_hp / full_hp))

        # Determine if it's a boss and get its specific prefix for the icon
        boss_prefix = self.get_boss_prefix(name)
        is_boss_monster = boss_prefix is not None

        if is_boss_monster:
            bar_base_width *= 1.2

        scale = self.get_scale(dist)

        # Use adjustable settings for bar dimensions
        bar_width = int(bar_base_width * scale)
        bar_height = int(self.base_height * scale)
        cap_w = int(self.left_cap_width * scale)
        cap_h = bar_height
        fill_h = int(self.fill_height * scale)

        fill_key = next((ch for ch in ["A", "B", "C"] if re.search(r" ([ABC])(?=\b|$)", name)), "default")
        if is_boss_monster:
            fill_key = "boss"
        elif current_hp_ratio <= 0.5 and "50" in self.fill_imgs_pil:
            fill_key = "50"
        elif current_hp_ratio <= 0.75 and "75" in self.fill_imgs_pil:
            fill_key = "75"

        current_fill_img_pil_source = self.fill_imgs_pil.get(fill_key, self.fill_imgs_pil.get("default"))
        
        hit_fill_img_pil_source = None
        if last_hit_damage > 0:
            if is_crit and "crit" in self.fill_imgs_pil:
                hit_fill_img_pil_source = self.fill_imgs_pil["crit"]
            elif "hit" in self.fill_imgs_pil:
                hit_fill_img_pil_source = self.fill_imgs_pil["hit"]


        mouseover_fill_img_pil_source = self.fill_imgs_pil.get("mouseover")
        dot_total_img_pil_source = self.fill_imgs_pil.get("dot_total")
        dot_tick_img_pil_source = self.fill_imgs_pil.get("dot_tick")
        boss_frame_img_pil_source = self.fill_imgs_pil.get("boss_frame")

        if any(img is None for img in [self.bg_img_pil, self.left_cap_img_pil, self.right_cap_img_pil, current_fill_img_pil_source]):
             print(f"Warning: Essential image asset missing for bar. Skipping bar for {name}.")
             return

        bar_x = int(x - bar_width // 2)
        bar_y = int(y - bar_height)
        
        main_fill_area_width = bar_width - (cap_w * 2)

        current_fill_width = int(current_hp_ratio * main_fill_area_width)
        current_fill_x = bar_x + cap_w

        dot_total_pixels = int(min(total_dot_damage / full_hp, 1.0) * main_fill_area_width) if full_hp > 0 else 0
        dot_tick_pixels = int(min(dot_tick_damage / full_hp, 1.0) * main_fill_area_width) if full_hp > 0 else 0

        dot_bar_y_pos = bar_y + (bar_height - fill_h) // 2

        # Drawing Order for HP Bar Components:
        # Draw bar elements only if bar_opacity > 0 (i.e., monster is alive)
        if bar_opacity > 0:
            # The background image for the bar (original background.png)
            bg_img_tk = self._get_tk_image(self.bg_img_pil, bar_width, bar_height, bar_opacity)
            self.canvas.create_image(bar_x, bar_y, anchor="nw", image=bg_img_tk)

            if is_targeted and mouseover_fill_img_pil_source:
                highlight_width = bar_width + (OVERLAY_HIGHLIGHT_BORDER_PX * 2)
                highlight_height = bar_height + (OVERLAY_HIGHLIGHT_BORDER_PX * 2)
                
                highlight_x = bar_x - OVERLAY_HIGHLIGHT_BORDER_PX
                highlight_y = bar_y - OVERLAY_HIGHLIGHT_BORDER_PX

                highlight_img_tk = self._get_tk_image(mouseover_fill_img_pil_source, highlight_width, highlight_height, bar_opacity)
                self.canvas.create_image(highlight_x, highlight_y, anchor="nw", image=highlight_img_tk)

            if hit_fill_img_pil_source:
                hit_fill_width = int(prev_hp_ratio * main_fill_area_width)
                
                if hit_fill_width > 0:
                    hit_fill_img_tk = self._get_tk_image(hit_fill_img_pil_source, hit_fill_width, fill_h, bar_opacity)
                    hit_fill_x = bar_x + cap_w
                    hit_fill_y = bar_y + (bar_height - fill_h) // 2
                    self.canvas.create_image(hit_fill_x, hit_fill_y, anchor="nw", image=hit_fill_img_tk)

            if current_fill_width > 0:
                current_fill_img_tk = self._get_tk_image(current_fill_img_pil_source, current_fill_width, fill_h, bar_opacity)
                self.canvas.create_image(current_fill_x, dot_bar_y_pos, anchor="nw", image=current_fill_img_tk)

            if total_dot_damage > 0 and dot_total_img_pil_source:
                dot_total_x_pos = current_fill_x + current_fill_width
                dot_total_img_tk = self._get_tk_image(dot_total_img_pil_source, dot_total_pixels, fill_h, bar_opacity)
                self.canvas.create_image(dot_total_x_pos, dot_bar_y_pos, anchor="nw", image=dot_total_img_tk)

            if dot_tick_damage > 0 and dot_tick_img_pil_source:
                dot_tick_x_pos = current_fill_x + current_fill_width + dot_total_pixels
                dot_tick_img_tk = self._get_tk_image(dot_tick_img_pil_source, dot_tick_pixels, fill_h, bar_opacity)
                self.canvas.create_image(dot_tick_x_pos, dot_bar_y_pos, anchor="nw", image=dot_tick_img_tk)

            left_cap_tk = self._get_tk_image(self.left_cap_img_pil, cap_w, cap_h, bar_opacity)
            self.canvas.create_image(bar_x, bar_y, anchor="nw", image=left_cap_tk)

            right_cap_tk = self._get_tk_image(self.right_cap_img_pil, cap_w, cap_h, bar_opacity)
            self.canvas.create_image(bar_x + bar_width - cap_w, bar_y, anchor="nw", image=right_cap_tk)

            # Draw specific boss icon if it's a boss monster with a known prefix
            if is_boss_monster and boss_prefix and boss_prefix in self.boss_icons_pil:
                icon_pil_source = self.boss_icons_pil[boss_prefix]
                icon_size_scaled = int(self.boss_icon_base_size * scale)
                
                # Position the icon to the left of the bar's start (bar_x)
                # Centered vertically with the bar
                icon_x = bar_x - icon_size_scaled - 5 # 5 pixel padding to the left
                icon_y = bar_y + (bar_height - icon_size_scaled) // 2

                boss_icon_tk = self._get_tk_image(icon_pil_source, icon_size_scaled, icon_size_scaled, bar_opacity)
                self.canvas.create_image(icon_x, icon_y, anchor="nw", image=boss_icon_tk)
            # Draw generic boss frame if it's a boss monster and a frame is available
            elif is_boss_monster and boss_frame_img_pil_source:
                # Use adjustable boss frame dimensions
                boss_frame_width = int(self.boss_frame_base_width * scale)
                boss_frame_height = int(self.boss_frame_base_height * scale)
                
                # Position it to the right of the bar, for example
                boss_frame_x = bar_x + bar_width - boss_frame_width
                boss_frame_y = (bar_y + (bar_height - fill_h) // 2 + fill_h) - boss_frame_height - 4
                
                boss_frame_tk = self._get_tk_image(boss_frame_img_pil_source, boss_frame_width, boss_frame_height, bar_opacity)
                self.canvas.create_image(boss_frame_x, boss_frame_y, anchor="nw", image=boss_frame_tk)

            # Display monster name and HP text
            display_name_hp_text = f"{name} {self.shorten_number(hp, self.shorten_number_digits)}/{self.shorten_number(full_hp, self.shorten_number_digits)}"
            name_hp_text_img_tk = self.render_text(display_name_hp_text, 
                                                   color=self.current_text_color, 
                                                   opacity=bar_opacity,
                                                   background_image_pil=self.fill_imgs_pil.get("text_bg"),
                                                   bg_opacity=bar_opacity)
            self.canvas.create_image(x, bar_y - 4, anchor="s", image=name_hp_text_img_tk)

        # "Dead" text - only if HP <= 0, using text_opacity (which will fade)
        if hp <= 0:
            dead_text_img_tk = self.render_text("Dead", 
                                                color=DEFAULT_DEAD_TEXT_COLOR, 
                                                opacity=text_opacity,
                                                background_image_pil=None, # Explicitly pass None here
                                                bg_opacity=0)
            dead_text_x = bar_x + (bar_width // 2)
            dead_text_y = bar_y + (bar_height // 2) - 7
            self.canvas.create_image(dead_text_x, dead_text_y, anchor="center", image=dead_text_img_tk)

    def update_bars(self, game_data):
        """
        Clears the canvas and redraws all monster and player health bars,
        handling close-range stacking.
        Manages monster fade-out for "Dead" text.
        """
        if self.error_occurred:
            self.display_error_on_canvas() # Keep showing the error message
            return # Do not proceed with drawing bars if an error has occurred

        try:
            current_time = time.time()

            new_monsters_list = game_data.get("Monsters", [])
            self.game_targeted_monster_index = game_data.get("TargetedMonsterIndex")
            players_list = game_data.get("Players", []) 

            self.canvas.delete("all")
            self.tk_image_references.clear()

            current_json_indices = {mon["Index"] for mon in new_monsters_list}
            
            monsters_to_draw_in_this_cycle = {}

            # --- Phase 1: Update monster states (fading, permanently hidden, or live) ---
            for mon in new_monsters_list:
                mon_idx = mon["Index"]
                
                if mon["HP"] > 0: # Monster is reported alive in JSON
                    # If monster was dead/fading, remove it from those states (it "resurrected")
                    if mon_idx in self.fading_monsters:
                        del self.fading_monsters[mon_idx]
                    if mon_idx in self.permanently_hidden_monsters:
                        self.permanently_hidden_monsters.remove(mon_idx)
                    
                    # Add to draw list as live (full opacity for both bar and text)
                    monsters_to_draw_in_this_cycle[mon_idx] = {
                        'data': mon.copy(),
                        'is_targeted': (mon_idx == self.game_targeted_monster_index),
                        'bar_opacity': 255,   # Full opacity for living monster's bar elements
                        'text_opacity': 255   # Full opacity for living monster's name/HP text
                    }
                else: # mon["HP"] <= 0: Monster is reported dead in JSON
                    # If it's already permanently hidden, do nothing (ignore it completely)
                    if mon_idx in self.permanently_hidden_monsters:
                        continue 
                    
                    # If it's not yet in the fading list, start its fade
                    if mon_idx not in self.fading_monsters:
                        self.fading_monsters[mon_idx] = {
                            'data': mon.copy(), # Store a copy of its current dead data
                            'start_fade_time': current_time,
                        }
                    
                    # Calculate current opacity for the "Dead" text
                    elapsed_fade_time = current_time - self.fading_monsters[mon_idx]['start_fade_time']
                    current_fade_opacity = max(0, 255 - int(255 * (elapsed_fade_time / FADE_OUT_DURATION)))
                    
                    # Add to draw list for dead monsters
                    monsters_to_draw_in_this_cycle[mon_idx] = {
                        'data': self.fading_monsters[mon_idx]['data'], # Use the updated data (which has HP=0)
                        'is_targeted': (mon_idx == self.game_targeted_monster_index),
                        'bar_opacity': 0, # Hide bar elements immediately
                        'text_opacity': current_fade_opacity # "Dead" text fades
                    }

            # --- Clean up fading_monsters: Remove those that have fully faded ---
            monsters_to_remove_from_fading = []
            for index, fade_data in list(self.fading_monsters.items()):
                # A monster should stop fading if:
                # 1. It is no longer in the current JSON input (it despawned while fading).
                # 2. Its fade animation duration has completed.
                if index not in current_json_indices or (current_time - fade_data['start_fade_time'] >= FADE_OUT_DURATION):
                    monsters_to_remove_from_fading.append(index)
                    # If the fade animation completed, mark it permanently hidden
                    if current_time - fade_data['start_fade_time'] >= FADE_OUT_DURATION:
                        self.permanently_hidden_monsters.add(index)

            for index in monsters_to_remove_from_fading:
                del self.fading_monsters[index]

            # --- Phase 2: Draw all collected monsters ---
            # Separate monsters into live (for layout) and dead (for fading text at fixed position)
            live_monsters_for_layout = []
            dead_monsters_for_fading = []

            for draw_item in monsters_to_draw_in_this_cycle.values():
                if draw_item['bar_opacity'] > 0: # This means it's a living monster
                    live_monsters_for_layout.append(draw_item)
                else: # This means it's a dead monster with fading text
                    dead_monsters_for_fading.append(draw_item)
            
            # Sort living monsters by distance for proper stacking (further monsters first)
            live_monsters_for_layout.sort(key=lambda x: x['data'].get('Distance', 9999), reverse=True)


            # Draw far-range active monsters
            far_monsters_for_drawing = [
                m for m in live_monsters_for_layout if self.close_range_threshold == 0 or m['data'].get('Distance', 9999) > self.close_range_threshold
            ]
            for draw_item in far_monsters_for_drawing:
                self.draw_bar(draw_item['data'], draw_item['is_targeted'], 
                            bar_opacity=draw_item['bar_opacity'], 
                            text_opacity=draw_item['text_opacity'])

            # Draw close-range active monsters (positioned in stack)
            close_monsters_for_drawing = [
                m for m in live_monsters_for_layout if self.close_range_threshold > 0 and m['data'].get('Distance', 0) <= self.close_range_threshold
            ]
            for i, draw_item in enumerate(close_monsters_for_drawing):
                mon_copy = draw_item['data'].copy()
                mon_copy["ScreenX"] = CLOSE_STACK_X
                mon_copy["ScreenY"] = CLOSE_STACK_START_Y - i * CLOSE_STACK_SPACING
                self.draw_bar(mon_copy, draw_item['is_targeted'], 
                            bar_opacity=draw_item['bar_opacity'], 
                            text_opacity=draw_item['text_opacity'])

            # Draw fading "Dead" text for dead monsters (at their last known position)
            # This needs to be drawn *after* all living bars, to ensure visibility if there's overlap.
            for draw_item in dead_monsters_for_fading:
                # We explicitly pass the properties for dead monsters, bar_opacity will be 0
                self.draw_bar(draw_item['data'], draw_item['is_targeted'],
                            bar_opacity=draw_item['bar_opacity'],
                            text_opacity=draw_item['text_opacity'])

        except Exception as e:
            self.log_error(f"Error during update_bars: {e}")
            self.error_occurred = True
            self.error_message = f"Rendering Error! See {os.path.basename(ERROR_LOG_FILE)}."
            self.display_error_on_canvas()


    def update_loop(self):
        """
        The main loop that continuously loads game data and updates the display.
        It now also periodically reloads settings to apply external changes.
        """
        if self.error_occurred:
            # If an error occurred, keep displaying the error message
            self.root.after(UPDATE_INTERVAL, self.update_loop)
            return

        try:
            self.load_settings() # Reload settings to pick up external changes
            game_data = self.load_game_data()
            self.update_bars(game_data)
        except Exception as e:
            self.log_error(f"Error in update_loop: {e}")
            self.error_occurred = True
            self.error_message = f"Update Loop Error! See {os.path.basename(ERROR_LOG_FILE)}."
            self.display_error_on_canvas()
            
        self.root.after(UPDATE_INTERVAL, self.update_loop)

def main():
    """
    Initializes the Tkinter root window and starts the OverlayApp.
    """
    root = tk.Tk()
    app = OverlayApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
