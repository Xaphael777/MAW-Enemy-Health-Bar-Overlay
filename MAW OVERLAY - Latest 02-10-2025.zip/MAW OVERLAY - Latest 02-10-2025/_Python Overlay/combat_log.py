import json
import time
import os

# --- Configuration ---
LOG_FILE_PATH = 'latest_combat_log.json'
# How often (in seconds) the script checks the file for a new message.
POLLING_INTERVAL_SECONDS = 0.5 

def display_latest_message(filepath):
    """
    Continuously reads the 'message' field from the JSON file and prints it
    to the console, overwriting the previous line to simulate a status overlay.
    """
    print("--- Combat Status Message Overlay Script Started ---")
    print(f"Monitoring: {filepath} (Check interval: {POLLING_INTERVAL_SECONDS}s)")
    
    # Store the last message printed to only update when necessary
    last_message = ""

    while True:
        try:
            # 1. Read and load the JSON file content
            with open(filepath, 'r') as f:
                content = json.load(f)
            
            # 2. Extract the message string. We assume the Lua script writes
            # a structure like: {"message": "Hero hits Goblin for 1234 points!"}
            current_message = content.get('message', "Status: Waiting for combat message...")
            
            # 3. Only print if the message has changed
            if current_message != last_message:
                # Print using carriage return (\r) to overwrite the line.
                # The '{:<80}' ensures the new message overwrites the old one fully.
                output_line = f"[{time.strftime('%H:%M:%S')}] {current_message}"
                print(f"{output_line:<80}", end='\r', flush=True)
                
                last_message = current_message
                
        except FileNotFoundError:
            # Print status message if the file doesn't exist yet
            print(f"File not found: {filepath}. Ensure your Lua script is running.", end='\r', flush=True)
        except json.JSONDecodeError:
            # Print status message if the file is empty or corrupted (e.g., being written)
            print(f"Error reading JSON from {filepath}. Waiting for stable content...", end='\r', flush=True)
        except Exception as e:
            # Print general errors without overwriting the main line
            print(f"\n[ERROR] An unexpected error occurred: {e}")
            
        # 4. Wait before checking again
        time.sleep(POLLING_INTERVAL_SECONDS)

if __name__ == "__main__":
    # Create an initial file content so the Python script has something to read at startup.
    try:
        with open(LOG_FILE_PATH, 'w') as f:
            json.dump({"message": "Overlay Ready: Awaiting first combat log..." }, f)
    except:
        pass # Ignore errors on file creation attempt

    # Start the display loop. Use try/except to handle Ctrl+C cleanly.
    try:
        display_latest_message(LOG_FILE_PATH)
    except KeyboardInterrupt:
        print("\n--- Overlay script stopped by user. ---")
